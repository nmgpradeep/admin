import CmsPages from './CmsPages';
import CmsPage from './CmsPage';
import CmsPageAdd from './CmsPageAdd';
import CmsPageEdit from './CmsPageEdit';

export {
  CmsPages, CmsPage ,CmsPageAdd , CmsPageEdit
};
