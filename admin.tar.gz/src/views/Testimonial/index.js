import Testimonial from './Testimonial'
import Testimonials from './Testimonials'

export {
    Testimonial,Testimonials,TestimonialEdit
}