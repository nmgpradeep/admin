module.exports = {
  'secret':'nodeauthsecret',
  //'database': 'mongodb://localhost/pitch-and-switch'
  'database': 'mongodb://pitchnswitch:nmg251@ds147450.mlab.com:47450/pitch-switch'
}
