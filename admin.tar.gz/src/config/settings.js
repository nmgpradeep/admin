module.exports = {
  'secret':'pitchandswitch'
};
