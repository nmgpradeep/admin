module.exports = {
    'PER_PAGE_RECORD': 10,
    
    ///Email setting
    'SMTP_HOST':'smtp.sendgrid.net',
    'SMTP_PORT': 587,
    'SMTP_USERNAME': 'rajivkr00',
    'SMTP_PASSWORD': 'rajiv@1234',
    'SMTP_FROM_EMAIL': '"pitchandswitch 👻" pitchandswitch.com',
    
};

