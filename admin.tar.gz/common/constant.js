module.exports = {
    'PER_PAGE_RECORD': 3,
    
    ///Email setting
    'SMTP_HOST':'smtp.sendgrid.net',
    'SMTP_PORT': 587,
    'SMTP_USERNAME': 'rajivkr00',
    'SMTP_PASSWORD': 'rajiv@1234',
    'SMTP_FROM_EMAIL': '"pitchandswitch 👻" pitchandswitch.com',
    'cmsimage_path':'/var/www/html/Node_ReactProject/admin/public/assets/uploads/cmsPageImage/'
   
    
};

